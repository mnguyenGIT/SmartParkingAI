import { useState, type ReactNode } from "react";

type IconName =
  | "grid"
  | "parking"
  | "car"
  | "users"
  | "chart"
  | "sparkles"
  | "settings"
  | "search"
  | "bell"
  | "arrow"
  | "trend"
  | "clock"
  | "chevron"
  | "plus"
  | "download"
  | "more";

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></>,
    parking: <><path d="M6 21V5a2 2 0 0 1 2-2h5.5a5.5 5.5 0 0 1 0 11H6" /><path d="M9 7h4.5a1.5 1.5 0 0 1 0 3H9" /></>,
    car: <><path d="m5 11 1.7-5.1A2 2 0 0 1 8.6 4h6.8a2 2 0 0 1 1.9 1.4L19 11" /><path d="M3 12a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5H3z" /><path d="M5 17v2M19 17v2" /><circle cx="7" cy="14" r=".8" /><circle cx="17" cy="14" r=".8" /></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8" /></>,
    chart: <><path d="M4 20V10M10 20V4M16 20v-7M22 20H2" /></>,
    sparkles: <><path d="m12 3-1.1 3.3a4 4 0 0 1-2.5 2.5L5 10l3.4 1.1a4 4 0 0 1 2.5 2.5L12 17l1.1-3.4a4 4 0 0 1 2.5-2.5L19 10l-3.4-1.2a4 4 0 0 1-2.5-2.5z" /><path d="m19 16-.5 1.5L17 18l1.5.5L19 20l.5-1.5L21 18l-1.5-.5z" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
    arrow: <><path d="M5 12h14M14 7l5 5-5 5" /></>,
    trend: <><path d="m3 17 6-6 4 4 8-8" /><path d="M15 7h6v6" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    download: <><path d="M12 3v12M7 10l5 5 5-5M5 21h14" /></>,
    more: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
}

function Button({ children, variant = "primary", onClick, className = "", ariaLabel }: { children: ReactNode; variant?: "primary" | "ghost" | "outline"; onClick?: () => void; className?: string; ariaLabel?: string }) {
  return <button type="button" className={`button button-${variant} ${className}`} onClick={onClick} aria-label={ariaLabel}>{children}</button>;
}

function Heading({ level = 2, children, className = "" }: { level?: 1 | 2 | 3; children: ReactNode; className?: string }) {
  const Tag = `h${level}` as "h1" | "h2" | "h3";
  return <Tag className={className}>{children}</Tag>;
}

const navItems: { label: string; icon: IconName }[] = [
  { label: "Tổng quan", icon: "grid" },
  { label: "Bãi đỗ xe", icon: "parking" },
  { label: "Lượt gửi xe", icon: "car" },
  { label: "Khách hàng", icon: "users" },
  { label: "Báo cáo", icon: "chart" },
  { label: "Trợ lý AI", icon: "sparkles" },
];

const activity = [
  { plate: "30A-456.78", action: "Check-in", time: "2 phút trước", zone: "A • 12", tone: "green" },
  { plate: "29B1-123.45", action: "Check-out", time: "8 phút trước", zone: "B • 08", tone: "orange" },
  { plate: "51H-887.21", action: "Check-in", time: "14 phút trước", zone: "C • 03", tone: "green" },
  { plate: "30K-092.64", action: "Check-out", time: "21 phút trước", zone: "A • 05", tone: "orange" },
];

function App() {
  const [activeNav, setActiveNav] = useState("Tổng quan");
  const [period, setPeriod] = useState("Hôm nay");
  const [showCheckin, setShowCheckin] = useState(false);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><span>P</span></div>
          <div><strong>SmartParking</strong><small>AI management</small></div>
        </div>

        <nav className="nav-list" aria-label="Điều hướng chính">
          <span className="nav-label">QUẢN LÝ</span>
          {navItems.map((item) => (
            <Button key={item.label} variant="ghost" className={`nav-item ${activeNav === item.label ? "active" : ""}`} onClick={() => setActiveNav(item.label)}>
              <Icon name={item.icon} /><span>{item.label}</span>
              {item.label === "Trợ lý AI" && <i>Mới</i>}
            </Button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <Button variant="ghost" className="nav-item"><Icon name="settings" /><span>Cài đặt</span></Button>
          <div className="system-status">
            <div className="status-top"><span><i /> Hệ thống</span><b>Ổn định</b></div>
            <div className="status-bar"><span /></div>
            <small>Cập nhật lúc 10:42</small>
          </div>
          <div className="profile">
            <div className="avatar">HN</div>
            <div><strong>Hoàng Nam</strong><small>Quản trị viên</small></div>
            <Icon name="more" size={18} />
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <span className="eyebrow">THỨ HAI, 17 THÁNG 6</span>
            <Heading level={1}>Chào buổi sáng, Nam</Heading>
          </div>
          <div className="top-actions">
            <label className="search-box">
              <Icon name="search" size={18} />
              <input aria-label="Tìm kiếm" placeholder="Tìm biển số, khách hàng..." />
              <kbd>⌘ K</kbd>
            </label>
            <Button variant="outline" className="icon-button notification" ariaLabel="Thông báo"><Icon name="bell" size={19} /><i /></Button>
            <Button onClick={() => setShowCheckin(true)}><Icon name="plus" size={18} /> Check-in xe</Button>
          </div>
        </header>

        <section className="hero-row">
          <div>
            <p className="intro">Tổng quan vận hành bãi xe theo thời gian thực.</p>
            <span className="live"><i /> Dữ liệu trực tiếp</span>
          </div>
          <div className="period-tabs">
            {["Hôm nay", "7 ngày", "30 ngày"].map((item) => <Button key={item} variant="ghost" className={period === item ? "selected" : ""} onClick={() => setPeriod(item)}>{item}</Button>)}
            <Button variant="outline"><Icon name="download" size={16} /> Xuất báo cáo</Button>
          </div>
        </section>

        <section className="stats-grid">
          <article className="stat-card">
            <div className="stat-icon orange"><Icon name="car" /></div>
            <div className="stat-meta"><span>XE ĐANG GỬI</span><b className="positive"><Icon name="trend" size={13} /> 8.2%</b></div>
            <strong className="stat-value">186</strong><small>so với 172 hôm qua</small>
          </article>
          <article className="stat-card">
            <div className="stat-icon blue"><Icon name="parking" /></div>
            <div className="stat-meta"><span>VỊ TRÍ CÒN TRỐNG</span><b className="neutral">34.2%</b></div>
            <strong className="stat-value">97</strong><small>trên tổng số 283 vị trí</small>
          </article>
          <article className="stat-card">
            <div className="stat-icon green"><span>₫</span></div>
            <div className="stat-meta"><span>DOANH THU HÔM NAY</span><b className="positive"><Icon name="trend" size={13} /> 12.5%</b></div>
            <strong className="stat-value">8,46M</strong><small>mục tiêu ngày 10,2M</small>
          </article>
          <article className="stat-card">
            <div className="stat-icon purple"><Icon name="clock" /></div>
            <div className="stat-meta"><span>LƯỢT XE HÔM NAY</span><b className="positive"><Icon name="trend" size={13} /> 5.4%</b></div>
            <strong className="stat-value">328</strong><small>142 lượt đã hoàn tất</small>
          </article>
        </section>

        <section className="dashboard-grid">
          <article className="panel occupancy-panel">
            <div className="panel-head">
              <div><Heading level={2}>Tình trạng bãi đỗ</Heading><p>Cập nhật theo từng khu vực</p></div>
              <Button variant="ghost">Xem chi tiết <Icon name="chevron" size={16} /></Button>
            </div>
            <div className="occupancy-content">
              <div className="gauge-wrap">
                <div className="gauge"><div><strong>65.8%</strong><span>đã lấp đầy</span></div></div>
                <div className="gauge-caption"><span><i className="occupied" /> Đã sử dụng <b>186</b></span><span><i className="available" /> Còn trống <b>97</b></span></div>
              </div>
              <div className="zone-list">
                {[
                  ["Khu A", "Ô tô", "78 / 100", "78%"],
                  ["Khu B", "Xe máy", "86 / 120", "72%"],
                  ["Khu C", "Hỗn hợp", "22 / 63", "35%"],
                ].map(([zone, type, count, width], i) => (
                  <div className="zone-row" key={zone}>
                    <div className={`zone-letter zone-${i}`}>{zone.slice(-1)}</div>
                    <div className="zone-info"><strong>{zone}</strong><span>{type}</span><div className="progress"><span style={{ width }} /></div></div>
                    <b>{count}</b>
                  </div>
                ))}
              </div>
            </div>
          </article>

          <article className="panel ai-card">
            <div className="ai-glow" />
            <div className="ai-head"><div className="ai-icon"><Icon name="sparkles" /></div><span>SMARTPARKING AI</span></div>
            <Heading level={2}>Dự báo giờ cao điểm</Heading>
            <p>Lưu lượng xe dự kiến tăng mạnh trong khung giờ <strong>17:00 – 19:00</strong> hôm nay.</p>
            <div className="ai-chart">
              {[24, 32, 28, 42, 58, 74, 91, 84, 61, 44].map((h, i) => <span key={i} className={i > 4 && i < 8 ? "hot" : ""} style={{ height: `${h}%` }} />)}
            </div>
            <div className="ai-axis"><span>12h</span><span>15h</span><span>18h</span><span>21h</span></div>
            <div className="ai-note"><Icon name="users" size={17} /><span>Đề xuất bổ sung <strong>2 nhân viên</strong> tại cổng B.</span></div>
            <Button variant="ghost" className="ai-action">Xem phân tích AI <Icon name="arrow" size={17} /></Button>
          </article>
        </section>

        <section className="lower-grid">
          <article className="panel revenue-panel">
            <div className="panel-head">
              <div><Heading level={2}>Doanh thu tuần này</Heading><p>So sánh với tuần trước</p></div>
              <div className="legend"><span><i className="this-week" /> Tuần này</span><span><i className="last-week" /> Tuần trước</span></div>
            </div>
            <div className="chart-wrap">
              <div className="y-axis"><span>12M</span><span>8M</span><span>4M</span><span>0</span></div>
              <div className="bar-chart">
                {[[68, 51], [74, 58], [62, 66], [88, 61], [79, 70], [92, 77], [55, 43]].map(([a, b], i) => (
                  <div className="bar-group" key={i}><div><span className="bar current" style={{ height: `${a}%` }} /><span className="bar previous" style={{ height: `${b}%` }} /></div><small>{["T2", "T3", "T4", "T5", "T6", "T7", "CN"][i]}</small></div>
                ))}
              </div>
            </div>
          </article>

          <article className="panel activity-panel">
            <div className="panel-head"><div><Heading level={2}>Hoạt động gần đây</Heading><p>Check-in & check-out mới nhất</p></div><Button variant="ghost">Xem tất cả <Icon name="chevron" size={16} /></Button></div>
            <div className="activity-list">
              {activity.map((item) => <div className="activity-row" key={item.plate}>
                <div className={`car-badge ${item.tone}`}><Icon name="car" size={18} /></div>
                <div className="plate"><strong>{item.plate}</strong><span>{item.action} • {item.time}</span></div>
                <div className="zone-tag"><span>{item.zone}</span><Icon name="chevron" size={14} /></div>
              </div>)}
            </div>
          </article>
        </section>
      </main>

      {showCheckin && <div className="modal-backdrop" onMouseDown={() => setShowCheckin(false)}>
        <div className="modal" onMouseDown={(event) => event.stopPropagation()}>
          <div className="modal-icon"><Icon name="car" /></div>
          <Heading level={2}>Check-in xe mới</Heading>
          <p>Nhập biển số để hệ thống kiểm tra và tự động phân bổ vị trí phù hợp.</p>
          <label className="field-label">BIỂN SỐ XE<input autoFocus placeholder="Ví dụ: 30A-123.45" /></label>
          <div className="modal-actions"><Button variant="outline" onClick={() => setShowCheckin(false)}>Hủy</Button><Button onClick={() => setShowCheckin(false)}>Kiểm tra vị trí <Icon name="arrow" size={17} /></Button></div>
        </div>
      </div>}
    </div>
  );
}

export default App;
